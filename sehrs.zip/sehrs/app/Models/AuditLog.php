<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use LogicException;

/**
 * Append-only audit trail. The app can insert rows but never change or delete them.
 * Part 12 (feature/audit-logs) adds the AuditLog::record() helper and observers.
 */
class AuditLog extends Model
{
    public const UPDATED_AT = null;   // table has created_at only

    protected $fillable = [
        'actor_id', 'action', 'resource_type', 'resource_id', 'ip_address', 'user_agent',
    ];

    protected static function booted(): void
    {
        static::updating(fn () => throw new LogicException('Audit logs are append-only.'));
        static::deleting(fn () => throw new LogicException('Audit logs are append-only.'));
    }

    public function actor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'actor_id');
    }
}
